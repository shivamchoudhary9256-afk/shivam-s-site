# FaceIQ — AI-Powered Facial Biometrics & Geometric Analysis

A modern, high-performance, and privacy-preserving computer vision web application for facial biometrics, cranial morphology, and aesthetic analysis.

---

## 📌 Project Overview

**FaceIQ** allows users to upload a facial portrait and inspect key biometric and morphological features:
1. **Estimated Biological Age** (DeepFace CNN regression)
2. **Facial Symmetry Analysis** (OpenCV 68-landmark bilateral triangulation)
3. **Face Shape Classification** (Morphological aspect ratio computation)
4. **Experimental Aesthetic Geometry** (Neoclassical Canons and Golden Ratio $\phi \approx 1.618$)

### Key Technical & Ethical Principles
- **No Mock Predictions:** In strict adherence to scientific integrity, no fabricated or simulated AI results are shown. Metric cards remain in verified standby status until connected to real inference pipelines.
- **Zero Photographic Retention:** Uploaded portraits are handled exclusively in volatile memory. No photographs are ever written to disk or sent to external databases.
- **Ethical & Subjectivity Disclaimers:** Clear contextualization that facial attractiveness is culturally and individually subjective, and age estimation models are statistical approximations subject to environmental conditions.

---

## 📂 Project Folder Structure

```text
faceiq/
│
├── frontend/
│   ├── index.html          # Semantic HTML5 markup containing all interface sections
│   ├── css/
│   │   └── style.css       # Custom design system (Dark navy SaaS theme, glassmorphism, responsive grid)
│   └── js/
│       └── app.js          # Client-side logic (drag-and-drop, validation, preview, modal status)
│
├── index.html              # Convenience root redirect to frontend/index.html
└── README.md               # Project documentation and local setup instructions
```

### Purpose of Each File

- `frontend/index.html`: Defines the document layout, navigation bar, hero banner, biometric drop zone, viewfinder preview card, the 4-card metric dashboard, ethical disclaimer, and information modal.
- `frontend/css/style.css`: Provides the visual identity. Features a modern dark navy/black background (`#080B13`), subtle blue and violet glowing gradients, glassmorphic cards (`backdrop-filter`), typography hierarchy, and full mobile-to-desktop responsiveness.
- `frontend/js/app.js`: Implements native drag-and-drop file ingestion, client-side format and file-size checks, in-memory image rendering using `FileReader`, image dimension extraction, and interactive placeholder modal notifications when the "Analyze" button is clicked.
- `index.html`: A root redirect that allows running a local HTTP server directly from the project root without navigating manually into subdirectories.

---

## 🚀 How to Run the Website Locally

You do not need to install any heavy packages or frameworks to test this frontend interface. Choose any of the following three methods:

### Method 1: Direct Browser Launch (Simplest)
1. Open File Explorer on Windows.
2. Navigate to `C:\Users\Hp\faceiq\frontend\`.
3. Double-click `index.html`. It will instantly open in your default browser (Chrome, Edge, Firefox, etc.).

### Method 2: Using Python's Built-in Server (Recommended)
Since Python is already part of your technology stack for the upcoming backend, you can use Python's built-in web server:

1. Open PowerShell or Terminal in the `faceiq` folder:
   ```powershell
   cd c:\Users\Hp\faceiq
   ```
2. Start the lightweight HTTP server:
   ```powershell
   python -m http.server 3000
   ```
3. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

### Method 3: VS Code Live Server Extension
1. Open the `faceiq` folder in Visual Studio Code.
2. Install the **Live Server** extension (by Ritwick Dey).
3. Right-click `frontend/index.html` in the file tree and select **"Open with Live Server"**.

---

## 🗺️ Implementation Roadmap

- [x] **Phase 1: Complete Frontend Interface & Styling Advisory** *(Current)*
  - Modern Dark Navy AI SaaS Dashboard UI
  - Drag-and-drop upload zone with file validation
  - In-memory viewfinder preview card with dimensions & file specs
  - 4-card metric dashboard architecture (Age, Symmetry, Shape, Golden Ratio)
  - **Interactive Hairstyle & Haircut Advisor:** Geometric matching across 6 face shapes (Oval, Round, Square, Heart, Oblong, Diamond) with cuts to avoid & beard pairing
  - **Eyewear & Facial Thirds Framing Guide:** Rule of contrast for optical frames and brow arches
  - **Dental & Jawline Harmony Screening ("Mouth Bracelet" / Braces & Aligners):** Oral landmark analysis (commissure tilt, lip competence, bite harmony indicators, and tongue posture)
  - Clear placeholder state explaining upcoming backend integration
  - Comprehensive ethical and clinical subjectivity disclaimers
- [ ] **Phase 2: Python & FastAPI Backend Integration** *(Next)*
  - FastAPI REST API endpoints
  - DeepFace model integration for age regression
  - OpenCV landmark detector (68 facial points) for symmetry and shape calculation
  - Automatic injection of detected face shape into the Hairstyle and Dental Advisory engine
  - CORS configuration and multipart form-data payload handler

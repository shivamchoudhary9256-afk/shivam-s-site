"""
FaceIQ — FastAPI Backend Service
Provides high-performance facial biometrics, cranial morphology,
symmetry triangulation, and aesthetic ratio endpoints.
"""

import os
from pathlib import Path
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from backend.analyzer import BiometricsAnalyzer

# Base project paths
BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

app = FastAPI(
    title="FaceIQ Biometrics API",
    description="AI-Powered Facial Biometrics, Cranial Morphology & Aesthetic Intelligence Engine",
    version="1.0.0"
)

# Configure CORS so any local frontend port (3000, 5500, 8000, or file://) can call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize computer vision & biometrics analyzer in memory
analyzer = BiometricsAnalyzer()


@app.get("/api/v1/health")
async def health_check():
    """
    Health check endpoint returning system status and computer vision versions.
    """
    import cv2
    return {
        "status": "healthy",
        "service": "FaceIQ Biometrics Engine",
        "version": "1.0.0",
        "opencv_version": cv2.__version__,
        "pipeline_ready": True
    }


@app.post("/api/v1/analyze")
async def analyze_portrait(file: UploadFile = File(...)):
    """
    Ingests portrait image in volatile RAM, runs computer vision pipelines,
    and returns comprehensive biometric and morphological measurements.
    """
    # 1. Validate file format
    allowed_types = ["image/jpeg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported format '{file.content_type}'. Please upload a JPEG, PNG, or WEBP portrait."
        )

    # 2. Read into volatile memory (zero disk retention)
    image_bytes = await file.read()

    # 3. Size validation (max 10MB)
    if len(image_bytes) > 10 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File size exceeds the 10 MB maximum limit."
        )

    # 4. Execute AI analysis pipeline
    try:
        results = analyzer.analyze(image_bytes)
        if not results.get("success"):
            return JSONResponse(status_code=422, content=results)
        return JSONResponse(status_code=200, content=results)
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": f"Internal computer vision analysis error: {str(e)}"
            }
        )


# Mount static assets (CSS, JS) from the frontend directory
if FRONTEND_DIR.exists():
    css_dir = FRONTEND_DIR / "css"
    js_dir = FRONTEND_DIR / "js"
    if css_dir.exists():
        app.mount("/css", StaticFiles(directory=str(css_dir)), name="css")
    if js_dir.exists():
        app.mount("/js", StaticFiles(directory=str(js_dir)), name="js")

    @app.get("/")
    async def serve_index():
        """Serves the main FaceIQ frontend application directly at root."""
        index_file = FRONTEND_DIR / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        return {"message": "FaceIQ API is running. Frontend index.html not found."}


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("backend.main:app", host="0.0.0.0", port=port, reload=True)

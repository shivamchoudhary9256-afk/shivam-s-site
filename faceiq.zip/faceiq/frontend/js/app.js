/**
 * ============================================================================
 * FaceIQ — Frontend Application Logic (Vanilla JavaScript)
 * ============================================================================
 * Handles:
 * - Drag and drop photo ingestion
 * - File validation (MIME type & size checks)
 * - In-memory image preview rendering & metadata extraction
 * - Phase 1 placeholder states & educational feedback modals
 * - Zero photographic data retention on client-side
 * ============================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // --------------------------------------------------------------------------
  // 1. DOM Element Selectors
  // --------------------------------------------------------------------------
  const dropZone = document.getElementById('drop-zone');
  const fileInput = document.getElementById('file-input');
  const browseBtn = document.getElementById('browse-btn');
  const previewCard = document.getElementById('preview-card');
  const imagePreview = document.getElementById('image-preview');
  
  // Preview Metadata Elements
  const previewName = document.getElementById('preview-name');
  const previewSize = document.getElementById('preview-size');
  const previewDimensions = document.getElementById('preview-dimensions');
  const previewType = document.getElementById('preview-type');
  
  // Action Buttons
  const analyzeBtn = document.getElementById('analyze-btn');
  const removeBtn = document.getElementById('remove-btn');
  const replaceBtn = document.getElementById('replace-btn');
  
  // Modal Elements
  const statusModal = document.getElementById('status-modal');
  const modalClose = document.getElementById('modal-close');
  const modalConfirmBtn = document.getElementById('modal-confirm-btn');
  const modalFilename = document.getElementById('modal-filename');

  // Toast Container
  const toastContainer = document.getElementById('toast-container');

  // Application State (Kept in volatile memory only)
  let currentFile = null;

  // Maximum allowed file size (10 MB in bytes)
  const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;
  const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

  // --------------------------------------------------------------------------
  // 2. Drag and Drop Event Handlers
  // --------------------------------------------------------------------------
  
  // Prevent default drag behaviors across the entire window
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    window.addEventListener(eventName, preventDefaults, false);
    dropZone.addEventListener(eventName, preventDefaults, false);
  });

  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }

  // Visual cues when dragging over the drop zone
  ['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, () => {
      dropZone.classList.add('drag-active');
    }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, () => {
      dropZone.classList.remove('drag-active');
    }, false);
  });

  // Handle dropped files
  dropZone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;

    if (files && files.length > 0) {
      processSelectedFile(files[0]);
    }
  });

  // Click on drop zone triggers file input (unless clicking a specific child button)
  dropZone.addEventListener('click', (e) => {
    if (e.target !== browseBtn && !browseBtn.contains(e.target)) {
      fileInput.click();
    }
  });

  browseBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    fileInput.click();
  });

  // Handle standard file picker selection
  fileInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files.length > 0) {
      processSelectedFile(e.target.files[0]);
    }
  });

  // --------------------------------------------------------------------------
  // 3. File Processing & Validation
  // --------------------------------------------------------------------------
  function processSelectedFile(file) {
    // 1. Validate MIME type
    if (!ALLOWED_MIME_TYPES.includes(file.type)) {
      showToast('Unsupported format. Please upload a JPEG, PNG, or WEBP portrait.', 'error');
      resetFileInput();
      return;
    }

    // 2. Validate File Size
    if (file.size > MAX_FILE_SIZE_BYTES) {
      showToast(`File exceeds limit. Maximum allowed size is 10 MB (selected: ${formatBytes(file.size)}).`, 'error');
      resetFileInput();
      return;
    }

    currentFile = file;

    // 3. In-memory FileReader (zero disk/cloud storage)
    const reader = new FileReader();

    reader.onload = (event) => {
      const dataUrl = event.target.result;
      
      // Update image preview element
      imagePreview.src = dataUrl;

      // Extract image natural pixel resolution
      const tempImg = new Image();
      tempImg.onload = () => {
        previewDimensions.textContent = `${tempImg.naturalWidth} × ${tempImg.naturalHeight} px`;
      };
      tempImg.src = dataUrl;

      // Populate file details
      previewName.textContent = file.name;
      previewSize.textContent = formatBytes(file.size);
      previewType.textContent = file.type || 'image/jpeg';

      // Switch views: hide drop zone and display viewfinder preview card
      dropZone.style.display = 'none';
      previewCard.style.display = 'block';

      // Smooth scroll to preview
      previewCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      showToast(`Loaded ${file.name} successfully into memory.`, 'info');
    };

    reader.onerror = () => {
      showToast('Failed to read image file. Please try another file.', 'error');
      resetFileInput();
    };

    reader.readAsDataURL(file);
  }

  // --------------------------------------------------------------------------
  // 4. Remove / Reset Image Functionality
  // --------------------------------------------------------------------------
  function resetFileInput() {
    currentFile = null;
    fileInput.value = '';
    imagePreview.src = '';
    previewDimensions.textContent = '-- × -- px';
    previewName.textContent = 'portrait.jpg';
    previewSize.textContent = '0.0 MB';
    previewType.textContent = 'image/jpeg';

    previewCard.style.display = 'none';
    dropZone.style.display = 'block';
  }

  removeBtn.addEventListener('click', () => {
    resetFileInput();
    showToast('Photo removed from volatile memory.', 'info');
  });

  replaceBtn.addEventListener('click', () => {
    fileInput.click();
  });

  // --------------------------------------------------------------------------
  // 5. Analyze Button — Live Computer Vision & AI Inference Pipeline
  // --------------------------------------------------------------------------
  analyzeBtn.addEventListener('click', async () => {
    if (!currentFile) {
      showToast('Please upload a facial portrait first.', 'warning');
      return;
    }

    setAnalyzingState(true);

    const formData = new FormData();
    formData.append('file', currentFile);

    // Dynamic endpoint URL (supports local server on 8000 or alternate ports)
    const apiUrl = (window.location.port === '8000') 
      ? '/api/v1/analyze' 
      : 'http://127.0.0.1:8000/api/v1/analyze';

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        const errorMsg = data.error || data.detail || 'Analysis failed. Please upload a clear frontal portrait with uniform lighting.';
        showToast(errorMsg, 'error');
        setAnalyzingState(false);
        return;
      }

      // Populate live AI metrics across all dashboard cards
      populateAnalysisResults(data);
      showToast('Facial biometrics & morphological analysis complete!', 'info');

      // Smooth scroll to results
      const resultsSection = document.getElementById('results-section');
      if (resultsSection) {
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }

    } catch (err) {
      console.warn('Backend connection error:', err);
      setAnalyzingState(false);
      showBackendOfflineModal();
    } finally {
      setAnalyzingState(false);
    }
  });

  function setAnalyzingState(isAnalyzing) {
    if (isAnalyzing) {
      analyzeBtn.disabled = true;
      analyzeBtn.innerHTML = `
        <span class="pulse-dot"></span>
        <span>Scanning Biometrics (OpenCV &amp; DeepFace)...</span>
      `;
    } else {
      analyzeBtn.disabled = false;
      analyzeBtn.innerHTML = `
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
        Analyze Facial Features
      `;
    }
  }

  function populateAnalysisResults(data) {
    // 1. Notice Banner Update
    const noticeEl = document.getElementById('integration-notice');
    if (noticeEl) {
      noticeEl.style.border = '1px solid rgba(16, 185, 129, 0.4)';
      noticeEl.style.background = 'linear-gradient(135deg, rgba(16, 185, 129, 0.12) 0%, rgba(99, 102, 241, 0.1) 100%)';
      const noticeTitle = noticeEl.querySelector('.notice-title');
      const noticeText = noticeEl.querySelector('.notice-text');
      const noticeBadge = noticeEl.querySelector('.notice-badge');
      if (noticeTitle) noticeTitle.textContent = 'AI Inference Complete • Biometric Pipeline Active';
      if (noticeText) noticeText.textContent = 'Facial landmarks, symmetry vectors, and cranial morphology successfully computed from your in-memory portrait.';
      if (noticeBadge) {
        noticeBadge.className = 'notice-badge';
        noticeBadge.style.color = '#34d399';
        noticeBadge.style.borderColor = 'rgba(16, 185, 129, 0.4)';
        noticeBadge.style.backgroundColor = 'rgba(16, 185, 129, 0.15)';
        noticeBadge.textContent = 'Verified Live';
      }
    }

    // 2. Card 1: Estimated Age
    const cardAge = document.getElementById('card-age');
    if (cardAge && data.age) {
      const valEl = cardAge.querySelector('.metric-value');
      const badgeEl = cardAge.querySelector('.card-header .badge');
      const summaryEl = cardAge.querySelector('.metric-summary');
      const detailValues = cardAge.querySelectorAll('.detail-value');
      const footerStatus = cardAge.querySelector('.footer-status');

      if (valEl) {
        valEl.textContent = data.age.estimated_age;
        valEl.classList.remove('placeholder-val');
      }
      if (badgeEl) {
        badgeEl.className = 'badge badge-success';
        badgeEl.textContent = 'Verified AI';
      }
      if (summaryEl) summaryEl.textContent = data.age.summary;
      if (detailValues.length >= 3) {
        detailValues[0].textContent = data.age.model;
        detailValues[1].textContent = data.age.confidence_band;
        detailValues[2].textContent = '200 OK (DeepFace)';
      }
      if (footerStatus) {
        footerStatus.innerHTML = '<span class="status-dot"></span> DeepFace CNN Inference Complete';
      }
    }

    // 3. Card 2: Facial Symmetry
    const cardSymmetry = document.getElementById('card-symmetry');
    if (cardSymmetry && data.symmetry) {
      const valEl = cardSymmetry.querySelector('.metric-value');
      const badgeEl = cardSymmetry.querySelector('.card-header .badge');
      const summaryEl = cardSymmetry.querySelector('.metric-summary');
      const detailValues = cardSymmetry.querySelectorAll('.detail-value');
      const footerStatus = cardSymmetry.querySelector('.footer-status');

      if (valEl) {
        valEl.textContent = data.symmetry.score;
        valEl.classList.remove('placeholder-val');
      }
      if (badgeEl) {
        badgeEl.className = 'badge badge-success';
        badgeEl.textContent = data.symmetry.category;
      }
      if (summaryEl) summaryEl.textContent = data.symmetry.summary;
      if (detailValues.length >= 3) {
        detailValues[0].textContent = 'OpenCV Sagittal Axis';
        detailValues[1].textContent = `Tilt: ${data.symmetry.horizontal_tilt}° | Variance: ${data.symmetry.left_right_variance}%`;
        detailValues[2].textContent = '200 OK (Bilateral Triangulation)';
      }
      if (footerStatus) {
        footerStatus.innerHTML = '<span class="status-dot"></span> Bilateral Symmetry Mapped';
      }
    }

    // 4. Card 3: Face Shape Classification
    const cardShape = document.getElementById('card-shape');
    if (cardShape && data.shape) {
      const valEl = cardShape.querySelector('.metric-value');
      const badgeEl = cardShape.querySelector('.card-header .badge');
      const summaryEl = cardShape.querySelector('.metric-summary');
      const detailValues = cardShape.querySelectorAll('.detail-value');
      const footerStatus = cardShape.querySelector('.footer-status');

      if (valEl) {
        valEl.textContent = data.shape.shape;
        valEl.classList.remove('placeholder-val');
      }
      if (badgeEl) {
        badgeEl.className = 'badge badge-success';
        badgeEl.textContent = 'Classified';
      }
      if (summaryEl) summaryEl.textContent = data.shape.explanation;
      if (detailValues.length >= 2) {
        detailValues[0].textContent = `Aspect Ratio: ${data.shape.aspect_ratio}`;
        detailValues[1].textContent = '200 OK (Cranial Aspect)';
      }
      if (footerStatus) {
        footerStatus.innerHTML = '<span class="status-dot"></span> Morphological Clustering Complete';
      }

      // Automatically trigger the hairstyle advisor to match detected shape!
      if (data.shape.shape) {
        renderFaceShapeAdvice(data.shape.shape.toLowerCase());
      }
    }

    // 5. Card 4: Aesthetic Geometry
    const cardAesthetic = document.getElementById('card-attractiveness');
    if (cardAesthetic && data.aesthetic) {
      const valEl = cardAesthetic.querySelector('.metric-value');
      const badgeEl = cardAesthetic.querySelector('.card-header .badge');
      const summaryEl = cardAesthetic.querySelector('.metric-summary');
      const detailValues = cardAesthetic.querySelectorAll('.detail-value');
      const footerStatus = cardAesthetic.querySelector('.footer-status');

      if (valEl) {
        valEl.textContent = data.aesthetic.index;
        valEl.classList.remove('placeholder-val');
      }
      if (badgeEl) {
        badgeEl.className = 'badge badge-success';
        badgeEl.textContent = 'Calculated';
      }
      if (summaryEl) summaryEl.textContent = data.aesthetic.summary;
      if (detailValues.length >= 3) {
        detailValues[0].textContent = `Proximity to φ: ${data.aesthetic.golden_ratio_proximity}%`;
        detailValues[1].textContent = 'Classical Proportions';
        detailValues[2].textContent = '200 OK (Neoclassical Canons)';
      }
      if (footerStatus) {
        footerStatus.innerHTML = '<span class="status-dot"></span> Golden Ratio (φ) Harmonized';
      }
    }

    // 6. Dental & Jawline Harmony Module Update
    const dentalCard = document.getElementById('dental-advisor');
    if (dentalCard && data.dental) {
      const statusPills = dentalCard.querySelectorAll('.harmony-status-pill');
      if (statusPills.length > 0) {
        statusPills[0].innerHTML = `<span class="status-dot"></span> Status: ${escapeHtml(data.dental.occlusal_status)} (${data.dental.cant_tilt}° plane tilt)`;
      }
      if (statusPills.length > 1) {
        statusPills[1].innerHTML = `<span class="status-dot"></span> ${escapeHtml(data.dental.recommendation)}`;
      }
      if (statusPills.length > 2) {
        statusPills[2].innerHTML = `<span class="status-dot"></span> ${escapeHtml(data.dental.tongue_posture)}`;
      }
    }
  }

  function showBackendOfflineModal() {
    const modalTitle = document.getElementById('modal-title');
    const modalSubtitle = statusModal.querySelector('.modal-subtitle');
    const modalBody = statusModal.querySelector('.modal-body');

    if (modalTitle) modalTitle.textContent = 'FastAPI Backend Service Offline';
    if (modalSubtitle) modalSubtitle.textContent = 'Python computer vision server not detected on port 8000';

    if (modalBody) {
      modalBody.innerHTML = `
        <div class="modal-highlight-box">
          <div class="highlight-item">
            <span class="badge badge-warning">Backend Inactive</span>
            <span>The frontend is ready, but the Python AI service must be running to process images.</span>
          </div>
        </div>

        <p class="modal-description">
          To enable real-time DeepFace and OpenCV facial analysis, run this command in your project directory:
        </p>

        <div style="background: #05070c; border: 1px solid var(--border-bright); padding: 0.85rem 1rem; border-radius: var(--radius-md); font-family: var(--font-mono); font-size: 0.88rem; color: #38bdf8; margin-bottom: 1.25rem;">
          python -m uvicorn backend.main:app --port 8000 --reload
        </div>

        <ul class="modal-checklist">
          <li><strong>Zero Data Retention:</strong> All processing is done strictly in RAM on your local machine.</li>
          <li><strong>Native AI Models:</strong> Runs OpenCV Haar cascade triangulation and DeepFace neural models.</li>
        </ul>
      `;
    }

    openModal();
  }

  // Modal controls
  function openModal() {
    statusModal.classList.add('is-open');
    statusModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    statusModal.classList.remove('is-open');
    statusModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  modalClose.addEventListener('click', closeModal);
  modalConfirmBtn.addEventListener('click', closeModal);

  statusModal.addEventListener('click', (e) => {
    if (e.target === statusModal) {
      closeModal();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && statusModal.classList.contains('is-open')) {
      closeModal();
    }
  });

  // --------------------------------------------------------------------------
  // 6. Face Shape Hairstyle & Grooming Advisory Engine
  // --------------------------------------------------------------------------
  const faceShapeData = {
    oval: {
      name: 'Oval',
      traits: 'Balanced cranial proportions with length roughly 1.5× width. Softly rounded jawline with no dominant corners.',
      bestStyles: [
        {
          name: 'Textured Quiff & Taper Fade',
          badge: 'Ideal Proportion',
          why: 'Emphasizes natural facial balance by adding subtle volume on top while keeping the sides cleanly tapered.'
        },
        {
          name: 'Classic Side Part / Comb Over',
          badge: 'Symmetry Flattering',
          why: 'Preserves balanced facial thirds without exaggerating width or height.'
        },
        {
          name: 'Medium Layered Flow / Waves',
          badge: 'Organic Frame',
          why: 'Softly traces cheekbone curvature without widening the temples.'
        }
      ],
      avoid: 'Extremely heavy, forward-falling blunt bangs that cover the entire forehead and disrupt the vertical rule of thirds.',
      beard: 'Clean-shaven, light 3-day designer stubble, or a trimmed short boxed beard.',
      eyewear: 'Versatile fit: geometric squares, browline clubmasters, or classic aviator frames.'
    },
    round: {
      name: 'Round',
      traits: 'Equal face width and length with soft, curved jawlines and prominent cheek apples.',
      bestStyles: [
        {
          name: 'High Pompadour / Faux Hawk',
          badge: 'Vertical Elongation',
          why: 'Adds height at the crown to visually lengthen the vertical facial ratio and counterbalance cheek width.'
        },
        {
          name: 'Textured French Crop with High Skin Fade',
          badge: 'Angular Contrast',
          why: 'Introduces sharp lines and angular geometry to offset natural soft curves.'
        },
        {
          name: 'Deep Asymmetrical Side Sweep',
          badge: 'Diagonal Break',
          why: 'Disrupts circular bilateral symmetry by drawing sightlines diagonally.'
        }
      ],
      avoid: 'Round chin-length bobs, uniform buzz cuts, or cuts with wide volume at the ears and cheekbones.',
      beard: 'Pointed goatee, Van Dyke, or beard kept close on cheeks and tapered longer at the chin to create jaw angularity.',
      eyewear: 'Angular rectangular, square, or geometric frames with sharp edges to sharpen soft contours.'
    },
    square: {
      name: 'Square',
      traits: 'Broad forehead with sharp, angular horizontal jawline and equal gonial-to-cheekbone width.',
      bestStyles: [
        {
          name: 'Textured French Crop with Mid Fade',
          badge: 'Angle Harmonizer',
          why: 'Softens the perimeter of the head while complementing the bold, masculine jaw definition.'
        },
        {
          name: 'Messy Side-Swept Waves / Undercut',
          badge: 'Dynamic Contrast',
          why: 'Adds textured motion on top to counter the rigid horizontal line of the jaw.'
        },
        {
          name: 'Classic Buzz Cut with Temple Fade',
          badge: 'Bone Structure Focus',
          why: 'Emphasizes naturally strong chiseled bone structure without distraction.'
        }
      ],
      avoid: 'Rigid, boxy flat-tops or blunt flat bangs that over-accentuate square edges.',
      beard: 'Rounded short beard, circle beard, or soft stubble to soften the hard 90° jaw corners.',
      eyewear: 'Round, oval, or teardrop aviator wireframes that provide organic curved contrast.'
    },
    heart: {
      name: 'Heart',
      traits: 'Broad forehead and prominent cheekbones tapering gracefully down to a pointed, delicate chin.',
      bestStyles: [
        {
          name: 'Mid-Length Layered Flow / Curtain Bangs',
          badge: 'Lower Balance',
          why: 'Adds fullness and texture around the jawline to balance the broader upper third.'
        },
        {
          name: 'Side-Swept Textured Fringe',
          badge: 'Forehead Softener',
          why: 'Visually reduces forehead width while directing focal attention toward the eyes.'
        },
        {
          name: 'Soft Crew Cut with Low Taper',
          badge: 'Controlled Volume',
          why: 'Maintains controlled top height without widening the temples.'
        }
      ],
      avoid: 'Excessive volume or spikes at the crown which exaggerate top-heavy triangular proportions.',
      beard: 'Fuller beard around the chin and lower jaw to add substantive width to a narrow chin.',
      eyewear: 'Bottom-heavy frames, thin rimless designs, or light oval shapes that do not crowd the upper third.'
    },
    oblong: {
      name: 'Oblong',
      traits: 'Facial length is notably greater than width with uniform cheek and jawline width.',
      bestStyles: [
        {
          name: 'Side Part with Scissor-Cut Sides',
          badge: 'Horizontal Width',
          why: 'Keeps moderate hair volume on the sides to visually broaden facial width.'
        },
        {
          name: 'Layered Forward Fringe / Textured Bangs',
          badge: 'Thirds Shortener',
          why: 'Covers part of the forehead, effectively shortening the vertical face length.'
        },
        {
          name: 'Medium Wavy Shag / Surfer Flow',
          badge: 'Lateral Texture',
          why: 'Creates width around the ears and cheekbones to harmonize long proportions.'
        }
      ],
      avoid: 'Towering pompadours, top knots, or high skin fades with extra height that further stretch vertical length.',
      beard: 'Moustache or neat stubble with short chin length (avoid long pointed goatees).',
      eyewear: 'Tall lenses, thick acetate square frames, or decorative temples that add horizontal presence.'
    },
    diamond: {
      name: 'Diamond',
      traits: 'Widest at high cheekbones with a narrow forehead hairline and a tapered, angular chin.',
      bestStyles: [
        {
          name: 'Textured Crop with Wispy Fringe',
          badge: 'Temple Width',
          why: 'Adds necessary volume across narrow temples and balances cheekbone prominence.'
        },
        {
          name: 'Chin-Length Layered Bob / Mid Flow',
          badge: 'Jawline Cushion',
          why: 'Fills the negative space beneath prominent cheekbones and softens the chin.'
        },
        {
          name: 'Side-Swept Comb Over with Low Taper',
          badge: 'Harmonious Flow',
          why: 'Directs sightlines across the forehead rather than vertically.'
        }
      ],
      avoid: 'Extreme high fades that leave temples completely bare; ultra-slicked back hairstyles.',
      beard: 'Full rounded chin beard or boxed beard to broaden the lower jawline.',
      eyewear: 'Browline clubmasters, cat-eye curves, or oval frames with detailed upper rims.'
    }
  };

  const hairDynamicContainer = document.getElementById('hair-dynamic-content');
  const shapeChips = document.querySelectorAll('.shape-chip');

  function renderFaceShapeAdvice(shapeKey) {
    const data = faceShapeData[shapeKey] || faceShapeData.oval;

    // Update active tab chip
    shapeChips.forEach(chip => {
      const isSelected = chip.getAttribute('data-shape') === shapeKey;
      chip.classList.toggle('active', isSelected);
      chip.setAttribute('aria-selected', isSelected ? 'true' : 'false');
    });

    if (!hairDynamicContainer) return;

    // Build best styles markup
    const stylesHtml = data.bestStyles.map(s => `
      <div class="hair-style-item">
        <div class="hair-style-top">
          <span class="hair-style-name">${escapeHtml(s.name)}</span>
          <span class="hair-match-badge">${escapeHtml(s.badge)}</span>
        </div>
        <p class="hair-style-why">${escapeHtml(s.why)}</p>
      </div>
    `).join('');

    hairDynamicContainer.innerHTML = `
      <div class="hair-layout-grid">
        <div class="hair-styles-list">
          <div style="margin-bottom: 0.25rem;">
            <strong style="color: #fff; font-size: 0.95rem;">Top Recommended Cuts for ${escapeHtml(data.name)} Shape:</strong>
            <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 0.2rem;">${escapeHtml(data.traits)}</p>
          </div>
          ${stylesHtml}
        </div>

        <div class="hair-side-column">
          <div class="hair-info-panel avoid-panel">
            <h5 class="panel-title">
              <span style="color: var(--accent-rose); font-weight: bold;">✕</span> Styles &amp; Cuts to Avoid
            </h5>
            <p class="panel-text">${escapeHtml(data.avoid)}</p>
          </div>

          <div class="hair-info-panel beard-panel">
            <h5 class="panel-title">
              <span style="color: var(--accent-blue); font-weight: bold;">✂</span> Facial Hair &amp; Beard Pairing
            </h5>
            <p class="panel-text">${escapeHtml(data.beard)}</p>
          </div>

          <div class="hair-info-panel" style="border-left: 3px solid var(--accent-indigo);">
            <h5 class="panel-title">
              <span style="color: var(--accent-indigo); font-weight: bold;">👓</span> Frame Geometry
            </h5>
            <p class="panel-text">${escapeHtml(data.eyewear)}</p>
          </div>
        </div>
      </div>
    `;
  }

  // Bind clicks on shape chips
  shapeChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const shape = chip.getAttribute('data-shape');
      renderFaceShapeAdvice(shape);
    });
  });

  // Initial render: default to Oval
  renderFaceShapeAdvice('oval');

  // --------------------------------------------------------------------------
  // 7. Toast Notification Helper
  // --------------------------------------------------------------------------
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    // Choose icon based on type
    let iconSvg = '';
    if (type === 'error') {
      iconSvg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#f43f5e" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
    } else if (type === 'warning') {
      iconSvg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fbbf24" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
    } else {
      iconSvg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#38bdf8" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
    }

    toast.innerHTML = `
      ${iconSvg}
      <span>${escapeHtml(message)}</span>
    `;

    toastContainer.appendChild(toast);

    // Trigger enter animation
    requestAnimationFrame(() => {
      toast.classList.add('toast-visible');
    });

    // Auto-dismiss after 4.5 seconds
    setTimeout(() => {
      toast.classList.remove('toast-visible');
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 4500);
  }

  // --------------------------------------------------------------------------
  // 7. Utility Functions
  // --------------------------------------------------------------------------
  function formatBytes(bytes, decimals = 1) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  function escapeHtml(string) {
    const entityMap = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    };
    return String(string).replace(/[&<>"']/g, s => entityMap[s]);
  }
});
